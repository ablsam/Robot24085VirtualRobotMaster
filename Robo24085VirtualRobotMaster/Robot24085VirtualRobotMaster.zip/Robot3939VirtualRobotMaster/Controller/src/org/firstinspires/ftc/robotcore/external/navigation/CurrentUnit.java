package org.firstinspires.ftc.robotcore.external.navigation;

public enum CurrentUnit {
    AMPS,
    MILLIAMPS
}
